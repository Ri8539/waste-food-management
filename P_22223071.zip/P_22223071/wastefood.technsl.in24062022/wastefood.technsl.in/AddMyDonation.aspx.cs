﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;

public partial class AddMyDonation : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["email"] == null)
            {
                Response.Redirect("LoginWithPassword.aspx");
            }
            string qr = "select * from [userinfo] where email = '" + Session["email"] + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(qr, con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            ad.Fill(ds);
            con.Close();
            first_name.Text = ds.Tables[0].Rows[0]["first_name"].ToString();
            last_name.Text = ds.Tables[0].Rows[0]["last_name"].ToString();
            email.Text = ds.Tables[0].Rows[0]["email"].ToString();
            //mobile.Text = ds.Tables[0].Rows[0]["mobile"].ToString();
            //address.Text = ds.Tables[0].Rows[0]["address"].ToString();

        }

        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
            //email unique
            //if (con.State == ConnectionState.Closed)
            con.Open();
            SqlCommand checkemail = new SqlCommand("select email from [donation] where email = @email and donation=@donation", con);
            checkemail.Parameters.AddWithValue("@email", email.Text);
            checkemail.Parameters.AddWithValue("@donation", donation.Text.ToString());
            SqlDataReader read = checkemail.ExecuteReader();
            if (read.HasRows)
            {
                lblErrorMsg.Text = "You already added this donation. ";
                lblErrorMsg.ForeColor = System.Drawing.Color.Red;
                con.Close();
            }
            else
            {
                con.Close();

                con.Open();
                string insertUsr = "insert into [donation] (first_name,last_name,email,donation) values (@first_name,@last_name,@email,@donation)";
                SqlCommand insertCmd = new SqlCommand(insertUsr, con);
                insertCmd.Parameters.AddWithValue("@first_name", first_name.Text);
                insertCmd.Parameters.AddWithValue("@last_name", last_name.Text);
                insertCmd.Parameters.AddWithValue("@email", email.Text);
                insertCmd.Parameters.AddWithValue("@donation", donation.Text.ToString());
                insertCmd.ExecuteNonQuery();
                con.Close();

                lblErrorMsg.Text = "Your donation added successfully.";
                lblErrorMsg.ForeColor = System.Drawing.Color.Green;
            }
        
    }
}